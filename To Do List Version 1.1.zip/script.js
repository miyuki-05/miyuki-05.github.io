const inputBox = document.getElementById("input-box");
const listContainer = document.getElementById("list-container");
const completedCounter = document.getElementById("completed-counter");
const uncompletedCounter = document.getElementById("uncompleted-counter");

inputBox.addEventListener("keypress", function(event) {
    if (event.key === "Enter") {
      event.preventDefault();
      document.getElementById("input-button").click();
    }
});

function loadList() {
    var number = 0;
    while (localStorage.getItem(`li${number}`) !== null) {
        const li = document.createElement("li");
        li.innerHTML = localStorage.getItem(`li${number}`);
        listContainer.appendChild(li);
        inputBox.value = "";
        updateCounters();
        makeElementsDraggable();
        
        const checkbox = li.querySelector("input");
        const editButton = li.querySelector(".edit-button");
        const taskSpan = li.querySelector("span");
        const deleteButton = li.querySelector(".delete-button");

        checkbox.addEventListener("click", function () {
            li.classList.toggle("completed", checkbox.checked);
            updateCounters();
        });

        editButton.addEventListener("click", function () {
            const update = prompt("Edit task:", taskSpan.textContent);
                if (update !== null) {
                    taskSpan.textContent = update;
                    li.classList.remove("completed");
                }
                checkbox.checked = false;
                updateCounters();
        });

        deleteButton.addEventListener("click", function () {
            if (confirm("Are you sure you want to delete this task?")) {
                li.remove();
                updateCounters();
            }
        });
        number++;
    }
}

function saveList() {
    localStorage.clear();
    const allListObjects = document.querySelectorAll("li");
    for (var i = 0; i < allListObjects.length; i++) {
        localStorage.setItem(`li${i}`, allListObjects[i].innerHTML);
    } 
}

function addTask() {
    const task = inputBox.value.trim();
    if (!task) {
        alert("Please write a task!");
        return;
    }
    const li = document.createElement("li");
    li.innerHTML = `
    <div ondragstart= "event.preventDefault()">
    <label>
    <input type="checkbox">
    <span>${task}</span>
    </label>
    <span class="edit-button">Edit</span>
    <span class="delete-button">Delete</span>
    </div>
    `;

    listContainer.appendChild(li);
    inputBox.value = "";
    updateCounters();
    makeElementsDraggable();
    

    const checkbox = li.querySelector("input");
    const editButton = li.querySelector(".edit-button");
    const taskSpan = li.querySelector("span");
    const deleteButton = li.querySelector(".delete-button");

    checkbox.addEventListener("click", function () {
        li.classList.toggle("completed", checkbox.checked);
        updateCounters();
    });

    editButton.addEventListener("click", function () {
        const update = prompt("Edit task:", taskSpan.textContent);
            if (update !== null) {
                taskSpan.textContent = update;
                li.classList.remove("completed");
            }
            checkbox.checked = false;
            updateCounters();
    });

    deleteButton.addEventListener("click", function () {
        if (confirm("Are you sure you want to delete this task?")) {
            li.remove();
            updateCounters();
        }
    });

    
}
function updateCounters() {
    const completedTasks = document.querySelectorAll(".completed").length;
    const uncompletedTasks =
      document.querySelectorAll("li:not(.completed)").length;
  
    completedCounter.textContent = completedTasks;
    uncompletedCounter.textContent = uncompletedTasks;
}

function makeElementsDraggable() {
    const draggables = document.querySelectorAll("li");
    for (let i = 0; i < draggables.length; i++) {
        draggables[i].draggable = "true";
      }
}


let draggedItem = null;
 
listContainer.addEventListener("dragstart", (e) => {
    draggedItem = e.target;
    setTimeout(() => {
        e.target.style.display =
            "none";
    }, 0);
});
 
listContainer.addEventListener("dragend", (e) => {
    setTimeout(() => {
        e.target.style.display = "";
        draggedItem = null;
    }, 0);
});
 
listContainer.addEventListener("dragover", (e) => {
    e.preventDefault();
    const afterElement =
        getDragAfterElement(
            listContainer,
            e.clientY);
    const currentElement =
        document.querySelector(
            ".dragging");
    if (afterElement == null) {
        listContainer.appendChild(
            draggedItem
        );} 
    else {
        listContainer.insertBefore(
            draggedItem,
            afterElement
        );}
    });
 
const getDragAfterElement = (container, y) => {
    const draggableElements = [
        ...container.querySelectorAll(
            "li:not(.dragging)"
        ),];
 
    return draggableElements.reduce(
        (closest, child) => {
            const box =
                child.getBoundingClientRect();
            const offset =
                y - box.top - box.height / 2;
            if (
                offset < 0 &&
                offset > closest.offset) {
                return {
                    offset: offset,
                    element: child,
                };} 
            else {
                return closest;
            }},
        {
            offset: Number.NEGATIVE_INFINITY,
        }
    ).element;
};

